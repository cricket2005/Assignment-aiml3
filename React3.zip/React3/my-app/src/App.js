
import React, { useState } from "react";
import "./App.css";

import Header from "./Header";
import Footer from "./Footer";
import EmployeeCard from "./EmployeeCard";
import EmployeeForm from "./EmployeeForm";

function App() {

  const [employees, setEmployees] = useState([
    {
      id: 1,
      name: "Rahul Das",
      employeeId: "EMP001",
      department: "IT",
      gender: "Male",
      phone: "9876543210",
      localAddress: "Kolkata",
      permanentAddress: "Durgapur"
    },
    {
      id: 2,
      name: "Priya Roy",
      employeeId: "EMP002",
      department: "HR",
      gender: "Female",
      phone: "9876543211",
      localAddress: "Howrah",
      permanentAddress: "Siliguri"
    }
  ]);

  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("All");
  const [editingEmployee, setEditingEmployee] = useState(null);

  // Add Employee
  const addEmployee = (employee) => {
    setEmployees([
      ...employees,
      {
        ...employee,
        id: Date.now()
      }
    ]);
  };

  // Delete Employee
  const deleteEmployee = (id) => {
    if (window.confirm("Are you sure you want to delete this employee?")) {
      setEmployees(
        employees.filter((employee) => employee.id !== id)
      );
    }
  };

  // Edit Employee
  const editEmployee = (employee) => {
    setEditingEmployee(employee);
  };

  // Update Employee
  const updateEmployee = (updatedEmployee) => {

    setEmployees(
      employees.map((employee) =>
        employee.id === updatedEmployee.id
          ? updatedEmployee
          : employee
      )
    );

    setEditingEmployee(null);
  };

  // Search + Department Filter
  const filteredEmployees = employees.filter((employee) => {

    const searchText =
      employee.name.toLowerCase().includes(search.toLowerCase()) ||
      employee.employeeId.toLowerCase().includes(search.toLowerCase()) ||
      employee.phone.includes(search);

    const departmentMatch =
      department === "All" ||
      employee.department === department;

    return searchText && departmentMatch;
  });

  return (
    <div>

      <Header />

      <div className="container">

        <h1>Employee Directory</h1>

        {/* Employee Count */}
        <div className="count-box">
          Total Employees: <strong>{employees.length}</strong>
        </div>

        {/* Add / Edit Form */}
        <EmployeeForm
          addEmployee={addEmployee}
          editingEmployee={editingEmployee}
          updateEmployee={updateEmployee}
        />

        {/* Search and Filter */}
        <div className="filter-box">

          <input
            type="text"
            placeholder="Search by name, ID or phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
          >
            <option value="All">All Departments</option>
            <option value="IT">IT</option>
            <option value="HR">HR</option>
            <option value="Accounts">Accounts</option>
            <option value="Production">Production</option>
            <option value="Marketing">Marketing</option>
          </select>

        </div>

        {/* Employee List */}
        <EmployeeList
          employees={filteredEmployees}
          editEmployee={editEmployee}
          deleteEmployee={deleteEmployee}
        />

      </div>

      <Footer />

    </div>
  );
}

export default App;